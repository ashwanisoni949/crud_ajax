<?php
#This is Init File
$settings = include_once __DIR__.'/settings.php'; 


